var jsTestButton = '.jsTestButton';
var shrinkPercentage = 90;
var defaultMaxWidth = 130;
var appValue = defaultMaxWidth;

var sels = [ '.l-header .l-header__inner', '.l-header', '.l-header', '.l-header .header-function .nav-icon-g', '.l-header .header-function .user-info', '.l-header .header-function .nav-log', '.searchbox-center .searchbox_in', '.searchbox-center', '.searchbox-center', '.main-top-slider .top-slider', '.selectric-wrapper .selectric .label', '.selectric-wrapper .selectric', '.search-form.search-product .select-wrap .selectric-wrapper .selectric', '.selectric-wrapper .selectric .label', '.search-form input', '.search-form input', '.search-form button', '.search-tags', '.search-tags', '.search-tags a', '.find-products', '.find-products', '.find-common-ttl', '.find-common-ttl', '.searchby-item .inner', '.searchby-item .search-heading .div-ttl .search-ttl', '.btn .btn-text', '.btn', '.btn', '.btn .btn-icon', '.btn .btn-icon', '.look-recommendations .recommend-item .inner', '.contact-bn .contact-bn_inner', '.contact-bn', '.contact-bn', '.contact-bn .text', '.searchby-item', '.searchby-item .search-list', '.searchby-item .search-list', '.searchby-item .search-list .search-list__item', '.searchby-item .search-list .search-list__item', '.searchby-item .search-list .search-list__item-in', '.searchby-item .search-list .search-list__item-in', '.searchby-item .search-list .search-list__item-in', '.searchby-item .search-list .search-list__item-in', '.search-location .search-list .search-list__item-in .thumb img', '.searchby-item .search-list .search-list__item .text', '.searchby-item .search-list .search-list__item .text', '.searchby-item .search-list .search-list__item .text', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-name', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-name', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-info', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-info'];
sels.push ( '.search-certification .certification-list', '.search-certification .certification-list', '.search-certification .certification-list', '.search-certification .certification-list', '.search-certification .certification-list', '.search-certification .certification-list', '.search-certification .certification-list', '.search-certification .certification-list .certification-item', '.search-certification .certification-list .certification-item__link', '.search-certification .certification-list .certification-item__link', '.look-recommendations .recommend-item .recommend-heading .div-ttl .recommend-ttl', '.look-recommendations .recommend-item .recommend-heading .div-ttl .recommend-ttl', '.look-recommendations .recommend-item .recommend-content', '.look-recommendations .recommend-item .recommend-content', '.look-recommendations .recommend-item .recommend-content', '.look-recommendations .recommend-note', '.look-recommendations .recommend-note', '.look-recommendations .recommend-note', 'body', 'body', '.sliders .slick-prev', '.sliders .slick-prev', '.sliders .slick-next', '.sliders .slick-next', '.look-recommendations .recommend-item .recommend-content .product-list .product-item', '.look-recommendations .recommend-item .recommend-content .product-list .product-item', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .btn-add', '.btn-add .btn-add__text', '.btn-add', '.btn-add', '.btn-add .btn-add__text::before', '.btn-add .btn-add__text::before', '.btn-add .btn-add__text::before', '.daruma .inner', '.l-footer .inner' );
var pros = [ 'max-width', 'padding-top', 'padding-bottom', 'margin-right', 'margin-right', 'margin-left', 'max-width', 'padding-top', 'padding-bottom', 'max-width', 'font-size', 'min-height', 'height', 'min-height', 'font-size', 'height', 'height', 'padding-top', 'padding-bottom', 'font-size', 'padding-bottom', 'padding-top', 'font-size', 'padding-bottom', 'max-width', 'font-size', 'font-size', 'width', 'height', 'width', 'height', 'max-width', 'max-width', 'padding-top', 'padding-bottom', 'font-size', 'padding-bottom', 'padding-right', 'padding-left', 'padding-right', 'padding-left', 'padding-top', 'padding-bottom', 'padding-right', 'padding-left', 'height', 'margin-top', 'font-size', 'line-height', 'font-size', 'line-height', 'font-size', 'line-height', 'padding-right', 'margin-left', 'margin-right', 'margin-top', 'padding-right', 'padding-top', 'padding-bottom', 'margin-bottom', 'font-size', 'line-height', 'font-size', 'line-height', 'padding-left', 'padding-right', 'margin-top', 'padding-left', 'line-height', 'margin-bottom', 'font-size', 'line-height', 'width', 'height', 'width', 'height', 'padding-left', 'padding-right', 'padding-left', 'padding-right', 'padding-top', 'margin-top', 'font-size', 'height', 'line-height', 'width', 'height', 'margin-right', 'max-width', 'max-width' ];
var vals = [ 176,  3.3,  3.5,  10,  7.97,  5.1,  130,  8,  9,  192,  1.8,  5.5,  5.5,  5.5,  1.8,  5.5,  5.5,  .9,  .9,  1.8,  13,  7,  3.8,  8.5,  163,  2.8,  1.8,  33.2,  5.5,  5.5,  5.5,  163,  155,  4.5,  4.5,  3.8,  9,  6,  6,  1.6,  1.6,  4,  4,  1.9,  1.9,  30,  4,  1.8,  3.3,  2.1,  3.4,  1.8,  3.3,  21,  6,  6,  8,  15,  5,  5,  6,  2.8,  3.5,  2.8,  3.5,  4.4,  4.4,  7.5,  2.5,  3.3,  1.5,  1.8,  3.3,  5.5,  5.5,  5.5,  5.5,  1.5,  1.5,  1.1,  1.1,  1.5,  1.5,  1.8,  5.5,  5.5,  2.7,  2.4,  2,  192,  150]
var units = [ 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem' ];

var objs = [ ];

elementNum = sels.length;

elementNumSel = sels.length;
elementNumPro = pros.length;
elementNumVal = vals.length;
elementNumUnit = units.length;


for(var i = 0; i < elementNum; i++) {
  var obj = { selector: sels[i],
              property: pros[i],
              value: vals[i],
              unit: units[i]};
  objs[i] = obj;
  console.log (objs[i]);
}

alert(elementNumSel + '個のセレクター\n' + elementNumPro + '個のプロパティ\n' + elementNumVal + '個の値\n' + elementNumUnit + '個の単位\n' );

$(function() {
  $(jsTestButton).on('click', function() {
    $(jsTestButton).removeClass(activeClass);
    var shrinkPercentage = $(this).addClass(activeClass).data('group');

    // appValue = appValue * (shrinkPercentage /1000);
    // appValue = defaultMaxWidth * (shrinkPercentage /1000);
    // console.log ("%: " + shrinkPercentage);
    // console.log ("appValue: " + appValue);

    for(var i = 0; i < elementNum; i++) {
    
      obj = objs[i]  
    
      appValue = obj.value * (shrinkPercentage /1000);
      // console.log ("%: " + shrinkPercentage);
      // console.log ("appValue: " + appValue);

      
    // $('.searchbox-center .searchbox_in').css('max-width', appValue + 'rem');
      $(obj.selector).css(obj.property, appValue + obj.unit);
    }

  })
})