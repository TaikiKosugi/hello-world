var jsTestButton = '.jsTestButton';
var shrinkPercentage = 90;
var defaultMaxWidth = 130;
var appValue = defaultMaxWidth;

var sels = [ '.l-header .l-header__inner', '.l-header', '.l-header', '.l-header .header-function .nav-icon-g', '.l-header .header-function .user-info', '.l-header .header-function .nav-log', '.searchbox-center .searchbox_in', '.searchbox-center', '.searchbox-center', '.main-top-slider .top-slider', '.searchby-item .inner', '.look-recommendations .recommend-item .inner', '.contact-bn .contact-bn_inner', '.contact-bn', '.contact-bn', '.contact-bn .text', '.searchby-item .search-list .search-list__item-in', '.searchby-item .search-list .search-list__item-in', '.search-location .search-list .search-list__item-in .thumb img', '.searchby-item .search-list .search-list__item .text', '.searchby-item .search-list .search-list__item .text', '.searchby-item .search-list .search-list__item .text', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-name', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-name', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-info', '.look-recommendations .recommend-item .recommend-content .product-list .product-item .product-item__in .product-body .product-info', '.btn', '.daruma .inner', '.l-footer .inner' ];
var pros = [ 'max-width', 'padding-top', 'padding-bottom', 'margin-right', 'margin-right', 'margin-left', 'max-width', 'padding-top', 'padding-bottom', 'max-width', 'max-width', 'max-width', 'max-width', 'padding-top', 'padding-bottom', 'font-size', 'padding-top', 'padding-bottom', 'height', 'margin-top', 'font-size', 'line-height', 'font-size', 'line-height', 'font-size', 'line-height', 'width', 'max-width', 'max-width' ];
var vals = [176,  3.3,  3.5,  10,  7.97,  5.1,  130,  8,  9,  192,  163,  163,  155,  4.5,  4.5,  3.8,  4,  4,  30,  4,  1.8,  3.3,  2.1,  3.4,  1.8,  3.3,  33.2,  192,  150]
var units = [ 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem', 'rem' ];

var objs = [ ];


elementNum = sels.length;

for(var i = 0; i < elementNum; i++) {
  var obj = { selector: sels[i],
              property: pros[i],
              value: vals[i],
              unit: units[i]};
  objs[i] = obj;
  console.log (objs[i]);
}

$(function() {
  $(jsTestButton).on('click', function() {
    $(jsTestButton).removeClass(activeClass);
    var shrinkPercentage = $(this).addClass(activeClass).data('group');

    // appValue = appValue * (shrinkPercentage /1000);
    // appValue = defaultMaxWidth * (shrinkPercentage /1000);
    // console.log ("%: " + shrinkPercentage);
    // console.log ("appValue: " + appValue);

    for(var i = 0; i < elementNum; i++) {
    
      obj = objs[i]  
    
      appValue = obj.value * (shrinkPercentage /1000);
      console.log ("%: " + shrinkPercentage);
      console.log ("appValue: " + appValue);

      
    // $('.searchbox-center .searchbox_in').css('max-width', appValue + 'rem');
      $(obj.selector).css(obj.property, appValue + obj.unit);
    }

  })
})