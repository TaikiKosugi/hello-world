jQuery(function ($) {
    var $window = $(window);
    var $document = $(document);
    var $html = $("html");
    var $body = $("body");
    const data_language = $("#wrapper").attr("data-lang");

    jQuery(function ($) {
        var selectSuggest = 0;
        var suggestions = [
            "Apple",
            "Apple sauce",
            "Apple vinegar",
            "Apple candy",
            "Apple fragrance",
        ];
        $(".search-input").on("keyup keypress", function (e) {
            const val = $(this).val();
            let suggestionsWrap = $(this).next(".suggestions");
            if (suggestionsWrap.length == 0) {
                suggestionsWrap = $("<div></div>").addClass("suggestions");
                $(this).after(suggestionsWrap);
            }
            if (!val) return;
            const suggestionsByValue = suggestions.filter((suggest) =>
                suggest.toLowerCase().includes(val.toLowerCase())
            );
            var key = e.which;
            if ([38, 40, 13].includes(key)) {
                switch (key) {
                    case 13: {
                        if (selectSuggest != 0) {
                            e.preventDefault();
                            suggestionsWrap.find(".select").trigger("click");
                            selectSuggest = 0;
                            console.log(selectSuggest);
                            suggestionsWrap.removeClass("show");
                            suggestionsWrap.html("");
                        }
                        return;
                    }
                    case 38: {
                        selectSuggest--;
                        if (selectSuggest < 1) selectSuggest = suggestionsByValue.length;
                        break;
                    }
                    default: {
                        selectSuggest++;
                        if (selectSuggest > suggestionsByValue.length) selectSuggest = 1;
                        break;
                    }
                }
            } else {
                selectSuggest = 0;
            }

            suggestionsWrap.removeClass("show");
            suggestionsWrap.html("");
            if (suggestionsByValue.length > 0) {
                let pos = 0;
                for (suggest of suggestionsByValue) {
                    pos++;
                    const suggestEl = $(`<div></div>`).addClass("suggest").text(suggest);
                    if (pos == selectSuggest) {
                        suggestEl.addClass("select");
                    }
                    suggestionsWrap.append(suggestEl);
                }
                suggestionsWrap.addClass("show");
            }
        });
        $body.on("click", function () {
            $(".suggestions").removeClass("show");
        });
        $(".search-wrap").on("click", ".suggestions .suggest", function () {
            const val = $(this).text();
            const suggestionsWrap = $(this).closest(".suggestions");
            suggestionsWrap.removeClass("show");
            suggestionsWrap.prev(".search-input").val(val);
        });
        $("#select-all").click(function () {
            const selectFor = $(this).data("for");
            $(`input[type="checkbox"][name="${selectFor}[]"]`).prop(
                "checked",
                this.checked
            );
        });
    });
    /* TOP */
    $(function () {
        var $slide = $(".top-slider")
            .slick({
                infinite: false,
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                arrows: false,
                fade: false,
                speed: 1000,
                autoplaySpeed: 5000,
                autoplay: false,
                pauseOnHover: false,
            })
            .on({
                beforeChange: function (event, slick, currentSlide, nextSlide) {
                    $(".slick-slide", this).eq(currentSlide).addClass("preve-slide");
                    $(".slick-slide", this).eq(nextSlide).addClass("fire");
                },
                afterChange: function () {
                    $(".preve-slide", this).removeClass("preve-slide fire");
                },
            });

        $slide.find(".slick-slide").eq(0).addClass("fire");
        $(window).resize(function () {
            //$('.top-slider').slick('setPosition');
        });
        var $slide2 = $(".p-slide")
            .slick({
                infinite: true,
                slidesToShow: 4,
                slidesToScroll: 1,
                dots: false,
                arrows: true,
                fade: false,
                speed: 1000,
                autoplaySpeed: 2000,
                autoplay: false,
                pauseOnHover: false,
                responsive: [
                    {
                        breakpoint: 1280,
                        settings: {
                            slidesToShow: 3,
                        },
                    },
                    {
                        breakpoint: 767,
                        // settings: "unslick"
                        settings: {
                            slidesToShow: 2,
                            swipeToSlide: true,
                            arrows: false,
                        },
                    },
                ],
            })
            .on({
                beforeChange: function (event, slick, currentSlide, nextSlide) {
                    $(".slick-slide", this).eq(currentSlide).addClass("preve-slide");
                    $(".slick-slide", this).eq(nextSlide).addClass("fire");
                },
                afterChange: function () {
                    $(".preve-slide", this).removeClass("preve-slide fire");
                },
            });
        $slide2.find(".slick-slide").eq(0).addClass("fire");
        var $slide3 = $(".specials-slider")
            .slick({
                infinite: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                arrows: false,
                speed: 500,
                autoplaySpeed: 2000,
                autoplay: false,
                pauseOnHover: false,
                adaptiveHeight: true,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 1,
                        },
                    },
                    {
                        breakpoint: 767,
                        // settings: "unslick"
                        settings: {
                            slidesToShow: 1,
                            swipeToSlide: true,
                        },
                    },
                ],
            })
            .on({
                beforeChange: function (event, slick, currentSlide, nextSlide) {
                    $(".slick-slide", this).eq(currentSlide).addClass("preve-slide");
                    $(".slick-slide", this).eq(nextSlide).addClass("fire");
                },
                afterChange: function () {
                    $(".preve-slide", this).removeClass("preve-slide fire");
                },
            });
        $slide3.find(".slick-slide").eq(0).addClass("fire");
        /***
         * Product Detail Slider
         */
        // DOM Ready
        // Initialize
        var slideWrapper = $(".product-slider"),
            iframes = slideWrapper.find(".embed-player");
        function checkTypeSlide(slick) {
            var currentSlide, slideType;
            currentSlide = slick.find(".slick-current");
            slideType = currentSlide.attr("class").split(" ")[1];
            if (slideType === "video") {
                slideWrapper.slick("slickRemove", 4);
            }
        }

        slideWrapper.on("init", function (event, slick) { });
        slideWrapper.on("beforeChange", function (event, slick) { });
        slideWrapper.on("afterChange", function (event, slick) { });

        $(".product-slider").slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: true,
            fade: false,
            dots: true,
            infinite: false,
            asNavFor: ".product-slider-thumb",
            lazyLoad: "progressive",
            cssEase: "cubic-bezier(0.87, 0.03, 0.41, 0.9)",
            responsive: [{

                breakpoint: 768,
                settings: {
                    arrows: false,

                }

            }],
            customPaging: function (slider, i) {
                if (slider.$slides[i].getAttribute("slide-data") == "video") {
                    return $('<button type="button" class="button-4video" />').text(
                        i + 1
                    );
                } else {
                    return $('<button type="button" />').text(i + 1);
                }
            },
        });

        $(".product-slider-thumb").slick({
            slidesToShow: 6,
            slidesToScroll: 1,
            asNavFor: ".product-slider",
            focusOnSelect: true,
            variableWidth: true,
        });
    });

    var btnSearch = $(".header-search__btn");
    var stateS = false;
    btnSearch.click(function () {
        if (stateS == false) {
            btnSearch.closest(".search-form-header").addClass("active");
            stateS = true;
        } else {
        }
    });

    function connectinput(textid, ischecked) {
        var ch = document.getElementById(textid);
        if (ischecked == true) {
            ch.disabled = false;
            ch.focus();
        } else {
            ch.disabled = true;
            ch.value = "";
            ch.blur();
        }
    }

    $("#other_value").click(function () {
        connectinput("other_str", this.checked);
    });
    $("#other_value2").click(function () {
        connectinput("other_str2", this.checked);
    });
    $("#other_value3").click(function () {
        connectinput("other_str3", this.checked);
    });
    function selectric_init() {
        if ($(".select-wrap").length) {
            $("select").selectric({
                responsive: false,
                nativeOnMobile: false,
                labelBuilder: function (currItem) {
                    return currItem.value != ""
                        ? currItem.text
                        : '<span class="normal">' + currItem.text + "</span>";
                },
                optionsItemBuilder: function (itemData, element, index) {
                    return itemData.value != ""
                        ? itemData.text
                        : '<span class="normal">' + itemData.text + "</span>";
                },
            });
        }
    }
    selectric_init();

    /* Toggle FAQ
      ---------------------------------------- */
    var speed = 300;
    /* -- toggle -- */
    if ($(".js-btn-oc").length > 0) {
        var $toggle_btn = $(".js-btn-oc"),
            $toggle_con = $(".js-pannel"),
            class_active = "btn-close",
            data_lang = $toggle_btn.attr("data-lang");
        $toggle_btn.on("click", function () {
            console.log(data_lang);
            $(this).toggleClass(class_active);
            $($toggle_con).slideToggle(speed);
            if (data_lang == "ja") {
                if ($(this).hasClass("btn-close")) {
                    this.querySelector(".btn-oc__text").innerHTML = "閉じる";
                } else {
                    this.querySelector(".btn-oc__text").innerHTML = "開く";
                }
            } else {
                if ($(this).hasClass("btn-close")) {
                    this.querySelector(".btn-oc__text").innerHTML = "Close";
                } else {
                    this.querySelector(".btn-oc__text").innerHTML = "Open";
                }
            }
        });
    }

    // ソート・フィルターのドロップダウン表示
    $(".p_sort-filter .p_sort-filter-button").on("click", function () {
        var $cl = $(this).closest(".p_sort-filter");
        if ($cl.hasClass("is-active")) {
            $cl.removeClass("is-active");
            $body.off("click.hide-sort-filter-dropdown");
        } else {
            for (var item of document.querySelectorAll(".p_sort-filter")) {
                item.classList.remove("is-active");
            }
            // $cl.siblings('.is-active').removeClass('is-active');
            $cl.addClass("is-active");
            $body.on("click.hide-sort-filter-dropdown", function () {
                $cl.removeClass("is-active");
            });
        }

        return false;
    });
    /**
     * ページトップ
     */
    var pagetop = $(".js-pagetop");
    pagetop.click(function () {
        $("body, html").animate(
            {
                scrollTop: 0,
            },
            700
        );
        return false;
    });
    /*     $window.scroll(function () {
              if ($(this).scrollTop() > 100) {
                  pagetop.fadeIn(1000);
              } else {
                  pagetop.fadeOut(300);
              }
          }); */
    $("#js-pagetop a").off("click.smoothscroll");

    var listview = $("#list-view"),
        tileview = $("#tile-view"),
        product = $("#product");
    listview.click(function () {
        $(this).addClass("active");
        tileview.removeClass("active");
        product.addClass("l-list_view");
    });
    tileview.click(function () {
        $(this).addClass("active");
        listview.removeClass("active");
        product.removeClass("l-list_view");
    });

    /**
     * enter related word
     */

    $(".related-word .related-word__item").on("click", function (e) {
        e.preventDefault();
        const val = $(this).text();
        const related_word = $(this).closest(".related-word");
        related_word.prev("form").children(".search-input").val(val);
        $("#s-input").val(val);
        $("#s-input").focus();
        // $(".search-form select").prop("selectedIndex", 1);
        $("select").selectric("refresh");
    });

    /**
     * hover map location in japan
     */
    $(".regions-item__list li a").on("mouseover", function (e) {
        e.preventDefault();
        const map_name = $(this).attr("data-map");
        $("#japan-maps-svg #" + map_name).css("fill", "#AAA07A");
        $("#japan-maps-svg ." + map_name).css("fill", "#AAA07A");
    });
    $(".regions-item__list li a").on("mouseleave", function (e) {
        e.preventDefault();
        const map_name = $(this).attr("data-map");
        $("#japan-maps-svg #" + map_name).removeAttr("style");
        $("#japan-maps-svg ." + map_name).removeAttr("style");
    });
    $("#japan-maps-svg path").on("mouseover", function (e) {
        e.preventDefault();
        const japan_maps_name = $(this).attr("data-name");
        $(".regions-item__list li a[data-map=" + japan_maps_name).css(
            "border-bottom-color",
            "#AAA07A"
        );
    });
    $("#japan-maps-svg path").on("mouseleave", function (e) {
        e.preventDefault();
        const japan_maps_name = $(this).attr("data-name");
        $(".regions-item__list li a[data-map=" + japan_maps_name).removeAttr(
            "style"
        );
    });
    $("#japan-maps-svg path").on("click", function (e) {
        e.preventDefault();
        const japan_maps_name = $(this).attr("data-name");
        const japan_maps_link = $(".regions-item__list li a[data-map=" + japan_maps_name).attr("href");
        console.log(japan_maps_link);
        window.open(japan_maps_link, "_self")
    });

    /* $('.product-slider').slick('slickFilter', function(filter){
         
      }); */

    $("#btn-settings").on("click", function () {
        $("#chris-dropdown-content").toggleClass("active");
    });
    $("#btn-settings-close").on("click", function () {
        $("#chris-dropdown-content").toggleClass("active");
    });
    $(".box-favourite-tab").on("mouseover", function () {
        $(".box-favourite-tab").removeClass("tab-hover");
        $(this).addClass("tab-hover");
    });
    $(".box-favourite-tab").on("mouseleave", function () {
        $(".box-favourite-tab").each(function () {
            $(this).removeClass("tab-hover");
            if ($(this).hasClass("js-active")) {
                $(this).addClass("tab-hover");
            }
        });
    });

    if ($("#agreement").length) {
        // 規約部分初期サイズチェック
        var proximity = 0.01;
        var scrollHeight = $("#terms_or_privacy")[0].scrollHeight;
        var scrollPosition =
            $("#terms_or_privacy")[0].offsetHeight +
            $("#terms_or_privacy")[0].scrollTop;
        if ((scrollHeight - scrollPosition) / scrollHeight <= proximity) {
            $("#agreement").prop("disabled", false);
        }

        $("#terms_or_privacy").on("scroll", function () {
            var proximity = 0.01;
            var scrollHeight = $(this)[0].scrollHeight;
            var scrollPosition = $(this)[0].offsetHeight + $(this)[0].scrollTop;
            if ((scrollHeight - scrollPosition) / scrollHeight <= proximity) {
                $("#agreement").prop("disabled", false);
            }
        });

        $("#agreement").on("click", function () {
            if ($(this).prop("checked")) {
                $("#btn-agree").prop("disabled", false);
            } else {
                $("#btn-agree").prop("disabled", true);
            }
        });

        $("#btn-agree").on("click", function () {
            $("#frmaction").submit();
        });
    }
    $(".btn-delete").on("click", function (e) {
        e.preventDefault();
        alert("This is an alert example!");
    });
    $(".product-cat__item .link-n-hover").on("mouseover", function () {
        $id_box = $(this).attr("href").split("#")[1];
        $($(this).attr("href")).addClass("box-hover");
    });
    $("ul.product-list-01__list a.link-n-hover").on("mouseover", function () {
        const item = $(this).closest("li");
        const parent = $(item).closest(".inner");
        const parent_width = parent.width();
        const offsetLeft = item.position().left;
        const popup = $(item).find(".box-content-of-product-cat");
        const elementWidth = $(popup).width();
        if (offsetLeft + elementWidth > parent_width) {
            $(popup).css("right", "0");
        } else {
            $(popup).removeAttr("style");
        }
    });
    const priority_order_kanji = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二", "十三", "十四", "十五", "十六", "十七", "十八", "十九", "二十", "二十一", "二十二", "二十三", "二十四", "二十五"];
    var priority_order = 3;
    $("#addmore-priority").on("change", function () {
        priority_order++;
        if (data_language == "ja") {
            priority_order_text = priority_order_kanji[priority_order-1]
        } else {
            priority_order_text = priority_order;
        }

        const div_clone = $("#priority-for-copy");
        const div_add = $("#priority-for-add");
        const note_hour = $("#note-hour");
        $("select").selectric("destroy");
        var y = div_clone.clone();
        y.removeAttr("id");
        note_hour.appendTo(y.find(".select-hour"));

        y.find(".priority-order").html(priority_order_text);
        y.find(".select-month select").attr("name", "month" + priority_order);
        y.find(".select-day select").attr("name", "day" + priority_order);
        y.find(".select-year select").attr("name", "year" + priority_order);
        // y.find(".select-hour input").attr("name", "hour" + priority_order);
        y.find(".select-hour .hour-item1 input").attr("name", "hour" + priority_order + "_1");
        y.find(".select-hour .hour-item2 input").attr("name", "hour" + priority_order + "_2");
        y.find(".select-hour .min-item1 input").attr("name", "min" + priority_order + "_1");
        y.find(".select-hour .min-item2 input").attr("name", "min" + priority_order + "_2");
        div_add.append(y);

        $("select").selectric("refresh"); // Reconstruct the plugin options box
        selectric_init();
        setTimeout(() => {
            $('#addmore-priority').prop('checked', false);
        }, 200);
    });
 /*    var container = document.getElementsByClassName("-way2")[0];
    container.onkeyup = function(e) {
        var target = e.srcElement;
        console.log(target)
        var maxLength = parseInt(target.attributes["maxlength"].value, 10);
        var myLength = target.value.length;
        if (myLength >= maxLength) {
            var next = $(this).closest().find(".hour1");
            console.log(next.find("input"))
            while (next = next.find("input")) {
                if (next == null)
                    break;
                if (next.tagName.toLowerCase() == "input") {
                    next.focus();
                    break;
                }
            }
        }
    }
     */
    /**
     * Button Onclick Follow
     */

    $(".btn-follow").on("click", function () {
        const btn = $(this);
        if (data_language == "ja") {
            if (btn.hasClass("-followed")) {
                btn.removeClass("-followed");
                btn.find(".btn-text").html("フォロー");
            } else {
                btn.addClass("-followed");
                btn.find(".btn-text").html("フォロー済み");
            }
        } else {
            if (btn.hasClass("-followed")) {
                btn.removeClass("-followed");
                btn.find(".btn-text").html("Follow");
            } else {
                btn.addClass("-followed");
                btn.find(".btn-text").html("Followed");
            }
        }

    });
    $(".filter-supplier .p_functions-filter__item").click(function (e) {
        var btn_filter = $(this);
        if (!btn_filter.hasClass("active")) {
            for (var item of document.querySelectorAll(
                ".filter-supplier .p_functions-filter__item"
            )) {
                item.classList.remove("active");
            }
            btn_filter.addClass("active");
        }
    });
    $(".filter-specials .p_functions-filter__item").click(function (e) {
        var btn_filter = $(this);
        if (!btn_filter.hasClass("active")) {
            for (var item of document.querySelectorAll(
                ".filter-specials .p_functions-filter__item"
            )) {
                item.classList.remove("active");
            }
            btn_filter.addClass("active");
        } else {
            btn_filter.removeClass("active");
        }
    });
    $(".product-list .btn-add").on("click", function () {
        const btn = $(this);
        var product_s = $("#product");
        if (data_language == "ja") {
            // if (btn.hasClass("-added")) {
            //     btn.removeClass("-added");
            //     if (product_s.hasClass("l-list_view")) {
            //         btn.find(".btn-add__text").html("登録");
                    
            //     } else {
            //         btn.find(".btn-add__text").html("お気に入り登録");
            //     }
            // } else {
            //     btn.addClass("-added");
            //     btn.find(".btn-add__text").html("登録済み!");
            // }

            if (btn.hasClass("-added")) {
                btn.removeClass("-added");
              
                if(btn.find(".btn-add__text .text-ft").length){
                    btn.find(".btn-add__text .text-ft").html("お気に入り登録");
                    btn.find(".btn-add__text .text-fl").html("登録");
                } else{
                    btn.find(".btn-add__text").html("お気に入り登録");
                }
            } else {
                btn.addClass("-added");
                if(btn.find(".btn-add__text .text-ft").length){
                    btn.find(".btn-add__text .text-ft").html("登録済み!");
                    btn.find(".btn-add__text .text-fl").html("登録済み!");
                } else{
                    btn.find(".btn-add__text").html("登録済み!");
                }
            }
        }
        else {
            if (btn.hasClass("-added")) {
                btn.removeClass("-added");
              
                if(btn.find(".btn-add__text .text-ft").length){
                    btn.find(".btn-add__text .text-ft").html("Add to list");
                    btn.find(".btn-add__text .text-fl").html("Add");
                } else{
                    btn.find(".btn-add__text").html("Add to list");
                }
            } else {
                btn.addClass("-added");
                if(btn.find(".btn-add__text .text-ft").length){
                    btn.find(".btn-add__text .text-ft").html("Added!");
                    btn.find(".btn-add__text .text-fl").html("Added!");
                } else{
                    btn.find(".btn-add__text").html("Added!");
                }
            }
        }
    });
    $(".btn-view").on("click", function () {
        var btn_text_add = $(".btn-add .btn-add__text");
        if (product_s.hasClass("l-list_view")) {
            btn.find(".btn-add__text").html("Add");
        } else {
            btn.find(".btn-add__text").html("Add to list");
        }
    });
    function setcss_4digit_number() {
        if ($('.div-info__number__item').length) {

            const get_num_html = $(".div-info__number__item");

            for (let i = 0; i < get_num_html.length; i++) {
                const div_digit_wrap = get_num_html[i];

                if (get_num_html[i].innerText.length == 4) {
                    $(div_digit_wrap).addClass("_4digit");
                }
            }
        }
    }
    setcss_4digit_number();

});
